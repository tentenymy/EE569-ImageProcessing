# EE569 Homework Assignment #3
# Date:     Nov 1, 2015
# Name:     Meiyi Yang
# ID:       6761-0405-85
# Email:    meiyiyan@usc.edu
#########################################################
# Compiled on OS X Yosemite Version 10.10.4
# Define compiler and linker in CMakeLists.txt
# 		cmake_minimum_required(VERSION 3.3)
# Coding in C++11
#########################################################
# 1. Usage for compiling, linking and running
# Compile, link and default run:
# Problem1:
# in HW3 root folder:
# Use cmake
cd p1
cmake .
make
./p1

# OR just use makefile: 
make
./p1
——————————————————————
# Problem2:
# in HW3 root folder:
# Use cmake
cd p2
cmake .
make
./p2

# OR just use  makefile: 
make
./p2
——————————————————————
# Problem3:
# in HW3 root folder:
# Use cmake
cd p3
cmake .
make
./p3

# OR just use makefile: 
make
./p3
——————————————————————
# Clean compiling files:
make clean
#########################################################
 * 2. File list and explanation
 * Problem1. Geometrical Modification
 * main implementing and testing file
 p1_main.cpp
 * class file
 Image.h
 Image.cpp

 * Problem2. Digital Half-toning
 * main implementing and testing file
 p2_main.cpp
 * class file
 Image.h
 Image.cpp
 Halftoning.h
 Halftoning.cpp

 * Problem3. Morphological Processing
 * main implementing and testing file
 * p3_main.cpp
 * class file
 Image.h
 Image.cpp
 Morphology.h
 Morphology.cpp
#########################################################