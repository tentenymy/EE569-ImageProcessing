Go to snk.m or interate.m for instrutions on how to run this code.
Copyright (c) Ritwik Kumar, Harvard University 2010
             www.seas.harvard.edu/~rkkumar
The code was written on MATLAB 6.5